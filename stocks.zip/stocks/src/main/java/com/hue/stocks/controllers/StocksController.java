package com.hue.stocks.controllers;


import com.hue.stocks.repositories.StocksRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StocksController {


   @GetMapping("/stocks")
   public String getStock(Model model) {
           model.addAttribute("record_id");
           return "stocks";
       }


   @GetMapping("/index")
    public String listAll(Model model){
       model.addAttribute("stocks",StocksRepository.class);
   return "index";
   }

   }


