package com.hue.stocks.model;


import javax.persistence.*;

@Entity
public class Stocks {
    @Id
    @SequenceGenerator(sequenceName = "stocks_s", name = "s_stocks")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "s_stocks")
    private Integer record_id;
    private String name;
    private Float price;
    private Integer volume;
//

    public Integer getRecord_id() {
        return record_id;
    }

    public void setRecord_id(Integer record_id) {
        this.record_id = record_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public Stocks(Integer record_id, String name, Float price, Integer volume) {
        this.record_id = record_id;
        this.name = name;
        this.price = price;
        this.volume = volume;
    }
}


