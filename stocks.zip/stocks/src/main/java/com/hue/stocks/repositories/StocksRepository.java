package com.hue.stocks.repositories;

import com.hue.stocks.model.Stocks;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StocksRepository extends CrudRepository<Stocks, Integer> {
}
